import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpHeaders, HttpClient } from '@angular/common/http'
import { Router, RouterModule, Routes} from '@angular/router';


@Component({
  //moduleId: module.id,
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private http: HttpClient,private router: Router
  ) {

  }
  hide = true;
  ngOnInit(): void {
  }
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,

  ]);
  pass = new FormControl('', [
    Validators.required,
  ]);
  onSubmit() {
    this.http.post('http://localhost:3000/login', {
      email: this.emailFormControl.value,
      password: this.pass.value
    }, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem("token")||"",
      }),
    }).subscribe({
      next: (responseData: any) => {
        console.log(responseData);
        localStorage.setItem("token",responseData.token)
        localStorage.setItem("data",responseData.email)
        this.router.navigate(['/home'])
      },
      error: (err)=> {
        alert(err.error);
    }
      });
  }
  
}
 



