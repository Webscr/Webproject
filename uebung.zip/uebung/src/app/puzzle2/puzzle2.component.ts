import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-puzzle2',
    templateUrl: './puzzle2.component.html',
    styleUrls: ['./puzzle2.component.css']
})
export class Puzzle2Component implements OnInit {

    constructor(private http: HttpClient, private router: Router) { }



    ngOnInit(): void {
        var zeit = Date.now();
        var interval = setInterval(timer, 1000);

        function timer() {
            var someDiv = document.getElementById('time');
            if(someDiv==null){
                clearInterval(interval);
                return 0
            }
            var children = someDiv!.childNodes;
            for(var i = 0; i < children.length; i++)
            someDiv!.removeChild(children[i]);
            var delta = Date.now() - zeit; // milliseconds elapsed since start
            var para = document.createElement('p');
            para.appendChild(document.createTextNode("Time: "+Math.floor(delta / 1000).toString()));
            document.getElementById("time")?.appendChild(para);
            return Math.floor(delta / 1000)
        }
        let pics = new Array();
        let clicked = new Array();

        for (let i = 1; i <= 9; i++) {
            let node = document.createElement("Img");
            let src = document.createAttribute("src");
            let style = document.createAttribute("style");
            var data = node.setAttribute("id", i + "");
            src.value = "assets/img2/img" + i + ".jpg";
            style.value = "border-style: solid";
            node.setAttributeNode(style);
            node.setAttributeNode(src);
            pics[i] = node;
            pics[i].addEventListener("click", clickpic);
        }
        function shuffle(array: number[]) {
            array.sort(() => 0.5 - Math.random());
            for (let i = 0; i < pics.length - 1; i++) {
                document.getElementById("pic2")?.appendChild(pics[i]);
                // if(moves==0){
                if ((i + 1) % 3 == 0) {
                    let br = document.createElement("br");
                    let foo = document.getElementById("pic2");
                    foo?.appendChild(br);
                }
            }
        }
        shuffle(pics);

        function clickpic(this: any) {
            clicked.push(this);
            let len = clicked.length;
            let tmp;
            clicked[0].classList.add("click");

            if (clicked[0] == clicked[1]) {//click same pic remove class
                clicked[0].classList.remove("click");
                clicked = [];
            } else if (len == 2) {
                clicked[1].classList.add("click");
                tmp = clicked[0].src;
                clicked[0].src = clicked[1].src;
                clicked[1].src = tmp;
                clicked[0].classList.remove("click");
                clicked[1].classList.remove("click");
                clicked = [];
                win()
            }
        }
        var that = this;
        function win() {
            let imgs = document.getElementsByTagName("img");
            let wintxt = document.createElement('h2');
            let style = document.createAttribute("style");
            style.value = "text-align:center;";
            wintxt.setAttributeNode(style);
            let correct = 0;
            for (let i = 1; i < 10; i++) {
                let str = imgs[i - 1].src;
                let compsrc = str.split('/');
                if ("assets/img2/img" + i + ".jpg" == compsrc[3] + "/" + compsrc[4] + "/" + compsrc[5]) {
                    correct++;
                }
                if (correct == 9) {
                    let time = timer();
                    wintxt?.appendChild(document.createTextNode('you solved it !!\n Total points: '+(100 - time)));
                    document.getElementById("spielbereich2")?.appendChild(wintxt);
                    document.getElementById("spielbereich2")?.classList.add("won");
                    clearInterval(interval);
                    if (localStorage.getItem("data")) {
                        time = 100 - time;
                        that.sendscore(time);
                    }
                }
            }
        }
    }
    sendscore(points: number) {
        this.http.post('http://localhost:3000/highscore', {
            email: localStorage.getItem("data"),
            score: points,
        }, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
            }),
        }).subscribe({
            next: (responseData: any) => {
                console.log(responseData);
            },
        });
    }

}
