import { Component, OnInit,Input } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-highscore',
  templateUrl: './highscore.component.html',
  styleUrls: ['./highscore.component.css']
})
export class HighscoreComponent implements OnInit {
  @Input() points: any[]=[];  
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get('http://localhost:3000/highscore', {
      }).subscribe({
        next:(responseData: any)=>{
          this.points.pop()
          this.points.push(responseData.scores)
          console.log(this.points)
        }
      });
  }

}
