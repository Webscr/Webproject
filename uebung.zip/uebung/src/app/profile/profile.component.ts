import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router, RouterModule, Routes} from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private http: HttpClient,private router: Router) { }
  points: any[]=[]
  ngOnInit(): void {
    this.http.get('http://localhost:3000/profile', {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem("data")||"",
      }),
    }).subscribe({
      next: (responseData: any) => {
        this.points.pop()
        this.points.push(responseData.data)
        console.log(responseData.data);
      },
      });
  }

}
