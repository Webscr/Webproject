import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router, RouterModule, Routes} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private http: HttpClient,private router: Router) { }

  ngOnInit(): void {
    if(localStorage.getItem("token")==""){
      this.router.navigate(["/login"])
    }
  }
  sendscore(){
    this.http.post('http://localhost:3000/highscore', {
      email: localStorage.getItem("data"),
      score:"90",
    },{
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    }).subscribe({
      next: (responseData: any) => {
        console.log(responseData);
      },
      });
  }
  points: any[]=[]
  getscore(){
    this.http.get('http://localhost:3000/highscore', {
      }).subscribe({
        next:(responseData: any)=>{
          this.points.pop()
          this.points.push(responseData.scores)
          console.log(this.points)
        }
      });
  }
  logout(){
    this.http.post('http://localhost:3000/logout', {
      }).subscribe({
        next:(responseData: any)=>{
          localStorage.clear();
          this.router.navigate(["/login"]);
        }
      });
  }
}
