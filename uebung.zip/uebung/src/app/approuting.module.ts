import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { PuzzleOverviewComponent } from './puzzle-overview/puzzle-overview.component';
import { HomeComponent } from './home/home.component';
import { BrowserModule } from '@angular/platform-browser';
import { PuzzleComponent } from './puzzle/puzzle.component';
import { HighscoreComponent } from './highscore/highscore.component';
import { FAQComponent } from './faq/faq.component';
import { LogoutComponent } from './logout/logout.component';
import { ProfileComponent } from './profile/profile.component';
import { Puzzle2Component } from './puzzle2/puzzle2.component';



const routes: Routes=[
  {path: 'login',component: LoginComponent},
  {path: 'logout',component: LogoutComponent},
  {path: 'signup',component: SignupComponent},
  {path: 'home',component:HomeComponent},
  {path: 'highscore',component:HighscoreComponent},
  {path: 'faq',component:FAQComponent},
  {path: 'profile',component:ProfileComponent},
  {path: 'puzzle-overview',component:PuzzleOverviewComponent, children:[
  {path: 'puzzle',component:PuzzleComponent},
  {path: 'puzzle2',component:Puzzle2Component}
  ]}
]

@NgModule({
  declarations: [],
  imports: [
    BrowserModule,RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class ApproutingModule { }
