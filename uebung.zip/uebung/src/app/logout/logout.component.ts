import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router, RouterModule, Routes} from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private http: HttpClient,private router: Router) { }

  ngOnInit(): void {
    this.http.post('http://localhost:3000/logout', {
    }).subscribe({
      next:(responseData: any)=>{
        localStorage.clear();
        this.router.navigate(["/login"]);
      }
    });
  }

}
