import { Component, OnInit } from '@angular/core';
import {FormControl, NgForm, Validators} from '@angular/forms';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http'


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(
    private http: HttpClient,
  ) { 
    
  }

  ngOnInit(): void {
  }
  
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  pass = new FormControl('', [
    Validators.required,
    Validators.minLength(8)
  ]);
  passv = new FormControl('', [
    Validators.required,
  ]);
  address = new FormControl('', [
    Validators.required,
  ]);
  city = new FormControl('', [
    Validators.required,
  ]);
  postalcode = new FormControl('', [
    Validators.required,
  ]);
  state = new FormControl('', [
    Validators.required,
  ]);
  
  onSubmit(form : NgForm) {
    if(this.pass.value==""||this.emailFormControl.value==""){
      alert("Please fill in every required field")
    }
      this.http.post('http://localhost:3000/signup', {
        email: this.emailFormControl.value,
        password: this.pass.value,
        address: this.address.value,
        city: this.city.value,
        postalcode: this.postalcode.value,
        state: this.state.value,
      }, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': localStorage.getItem("token")||"",
        }),
      }).subscribe({
        next: (responseData: any) => {
          console.log(responseData)
          alert("successful signup");
          localStorage.setItem("token",responseData.token)
        },
        error: (err)=> {
          alert(err.error);
      }});
  }
  hide = true;
  hide2=true;
}

