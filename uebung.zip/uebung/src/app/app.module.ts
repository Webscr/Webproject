import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import { BrowserModule } from '@angular/platform-browser';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import {MatCardModule} from '@angular/material/card';
import {MatTableModule} from '@angular/material/table';
import { ReactiveFormsModule } from '@angular/forms'
import { MatInputModule } from '@angular/material/input';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { MatSelectModule } from '@angular/material/select';
import { ApproutingModule } from './approuting.module';
import { SignupComponent } from './signup/signup.component';
import { MatTabsModule } from '@angular/material/tabs';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { Router, RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HighscoreComponent } from './highscore/highscore.component';
import { LogoutComponent } from './logout/logout.component';
import { PuzzleComponent } from './puzzle/puzzle.component';
import { Puzzle2Component } from './puzzle2/puzzle2.component';
import { PuzzleOverviewComponent } from './puzzle-overview/puzzle-overview.component';
import { ProfileComponent } from './profile/profile.component';
import { FAQComponent } from './faq/faq.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatExpansionModule} from '@angular/material/expansion';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    HighscoreComponent,
    LogoutComponent,
    PuzzleComponent,
    Puzzle2Component,
    PuzzleOverviewComponent,
    ProfileComponent,
    FAQComponent,
  ],
  imports: [
    MatTableModule,
    BrowserModule,
    RouterModule,
    MatButtonModule,
    MatCardModule,
    HttpClientModule,
    BrowserModule,
    MatTabsModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    ApproutingModule,
    MatToolbarModule,
    MatExpansionModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
