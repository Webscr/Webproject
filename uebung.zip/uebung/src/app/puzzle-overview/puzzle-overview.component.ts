import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-puzzle-overview',
  templateUrl: './puzzle-overview.component.html',
  styleUrls: ['./puzzle-overview.component.css']
})

export class PuzzleOverviewComponent implements OnInit {

  chosen=false;
  constructor() { }

  ngOnInit(): void {
  
  }
  choose(){
    this.chosen=true;
  }

}
