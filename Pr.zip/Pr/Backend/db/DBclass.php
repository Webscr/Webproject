<?php
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
require_once '' . $root . '\SS2021\Pr\Backend\config\config.php';

class DB
{
    private $conn;
    public $getvotes;

    public function __construct()
    {
        global $con;
        $this->conn = $con;
    }
    private function Close($con)
    {
        mysqli_close($con);
    }

    public function getAppointments(){
        $conn = $this->conn;
        $stmt = $conn->query("SELECT*FROM appointments");
        $row = $stmt->num_rows;
        if ($row > 0) {
            while ($row = $stmt->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        }
    }
    public function getvotes($q){
        $conn = $this->conn;
        $stmt = $conn->prepare("SELECT Username,TID,Vote FROM userap WHERE Username=?");
        $stmt->bind_param("s",$q);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($user,$id,$vote);
        while ($stmt->fetch()) {
            echo 'User: '.$user.'<br>';
            echo 'Vote '.$vote.'<br>';
        }
    
        
        return $id;
        //return $newrow;
    }
    public function getTID($id){
        $conn = $this->conn;
        $stmt2 = $conn->prepare("SELECT Datum FROM terminoption WHERE ID=?");
        $stmt2->bind_param("i",$id);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        $date= $result2->fetch_all(MYSQLI_ASSOC);
        return $date[0];
    }
    public function newAppointment($appObject){
         // Define query to insert values into the users table
         $sql = "INSERT INTO appointments(Titel,Ort,Datum,Ablaufdatum,Kommentar) VALUES(?,?,?,?,?);";
 
         $conn = $this->conn;
         // Prepare the statement
         $query = $conn->prepare($sql);
 
         // Bind parameters
         $query->bind_param("sssss", $appObject->titel, $appObject->ort, $appObject->datum, $appObject->ablaufdatum,$appObject->kommentar);
         // Execute the query
         $query->execute();

         $lastid=$conn->insert_id;
         $query->free_result();

       
        $vote=0;
         foreach ($appObject->option as $x => $date) {
         $terminsql="INSERT INTO terminoption(Datum,Votings,AppointmentID) VALUES(?,?,?);";
         $query2=$conn->prepare($terminsql);
         $query2->bind_param("sii",$date,$vote,$lastid);
         $query2->execute();
         }
         
         
         //$this->Close($conn);
    }
   
    public function terminoption($id){
        $conn = $this->conn;
        $result = $conn->prepare("SELECT*FROM terminoption WHERE AppointmentID=?;");
        $result->bind_param("i", $id);
        $result->execute();
        $stmt = $result->get_result();
        $row = $stmt->fetch_all(MYSQLI_ASSOC);
        return $row;

    }
    public function vote($id,$user,$vote,$cmt,$apid){
        $sql = "INSERT INTO userap(Username,TID,APID,Vote,Comment) VALUES(?,?,?,?,?);";
 
         $conn = $this->conn;
         // Prepare the statement
         $query = $conn->prepare($sql);
         // Bind parameters
         $query->bind_param("siiss", $user,$id,$apid,$vote,$cmt);
         // Execute the query
         $query->execute();
    
    }
    public function checkvote($user){
        $conn = $this->conn;
        $result = $conn->prepare("SELECT * FROM userap WHERE Username=?;");
        $result->bind_param("s", $user);
        $result->execute();
        $result->store_result();
        $result->fetch();
        var_dump($result->num_rows(),$user);
        if($result->num_rows>0){
            return true;
        }
        return false;
    }
    public function addVote($id){
        $conn = $this->conn;
        $sqlupd="UPDATE terminoption SET Votings=Votings+1 WHERE ID=?";
        $result=$conn->prepare($sqlupd);
        $result->bind_param("i", $id);
        $result->execute();
     
    }
    public function updateVote($user,$id,$apid){
        $conn = $this->conn;
        $sqlupd="UPDATE userap SET TID=? WHERE APID=? AND Username=?";
        $result=$conn->prepare($sqlupd);
        $result->bind_param("iis", $id,$apid,$user);
        $result->execute();
    }
    public function getComments($id){
        $conn = $this->conn;
        $result = $conn->prepare("SELECT Username,Comment FROM userap WHERE TID=?;");
        $result->bind_param("i", $id);
        $result->execute();
        $stmt = $result->get_result();
        $row = $stmt->fetch_all(MYSQLI_ASSOC);
        return $row;
    }
    public function delete($id){
        $conn = $this->conn;
        $result = $conn->prepare("DELETE FROM appointments WHERE ID=?;");
        $result->bind_param("i", $id);
        $result->execute();
        $result = $conn->prepare("DELETE FROM terminoption WHERE AppointmentID=?;");
        $result->bind_param("i", $id);
        $result->execute();
        $result = $conn->prepare("DELETE FROM userap WHERE APID=?;");
        $result->bind_param("i", $id);
        $result->execute();
        var_dump($result);
        
    }

}