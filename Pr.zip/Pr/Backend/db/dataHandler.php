<?php
include("./models/Appointment.php");
require "DBclass.php";

class DataHandler
{

    private $db;
    public $newapp;

    public function queryAppointments()
    {
        $res =  $this->getData();
        return $res;
    }
    public function queryTermin($id)
    {
        $res = $this->db->terminoption($id);
        return $res;
    }

    public function __construct()
    {
        $this->db = new DB();
    }

    public function getData()
    {
        $demodata = $this->db->getAppointments();
        return $demodata;
    }
    public function getComments($id){
        $comments=$this->db->getComments($id);
        return $comments;
    }
    public function insertData($tit, $ort, $dt, $adt,$option)
    {
        $newapp = new Appointment($tit, $ort, $dt, $adt," ",$option);
        $this->db->newAppointment($newapp);
    }
    public function Voting($id,$user,$vote,$cmt,$apid){
        if($this->db->checkvote($user)==true){
            $this->db->updateVote($user,$id,$apid);
        }else{
        $this->db->addVote($id);
        $this->db->vote($id,$user,$vote,$cmt,$apid);
        }
    }
    public function delete($id){
        $this->db->delete($id);
    }
    public function getuservotes($q){
        $id=$this->db->getvotes($q);
        $res=$this->db->getTID($id);
        return $res;
    }
}
