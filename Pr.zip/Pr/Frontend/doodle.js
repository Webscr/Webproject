"use strict";
/*
   Achtung - wichtige Hinweise:
   -----------------------------------------------------------------------------
   1) Sollte VSC jQuery nicht kennen, dann müssen die Typen erst importiert werden
      Führen Sie dazu Folgendes im Terminal von VSC aus:
         npm install --save @types/jquery
   2) Fehlermeldung beim Ausführen von Ajax-Requests:
      "Quellübergreifende (Cross-Origin) Anfrage blockiert: Die Gleiche-Quelle-Regel verbietet das Lesen der externen Ressource ..."
      --> das passiert wenn Client und Server von unterschiedlichen Quellen kommen
          (z.B. Client: http://localhost:3000/...
                Server: http://localhost:80/... )
      --> dann muss für den Server angegeben werden, dass er das Ergebnis ausliefern darf
      --> Erstellen einer .htaccess - Datei im Verzeichnis der anzusprechenden PHP-Datei mit folgendem Inhalt:
             Header set Access-Control-Allow-Origin "*"
*/
var _a, _b;
// Settings:
var restServer = "http://localhost:80/SS2021/Pr/Backend/serviceHandler.php";
var jsondata = new Array;
//------------------------------GET APPOINTMENTS AND DISPLAY THEM----------------------------------
$.getJSON(restServer, { 'method': 'getAppointment' }, function (data) {
    data.forEach(function (item) {
        var expire = "";
        var hide = "";
        var date = new Date(item.Ablaufdatum);
        var now = new Date;
        if (+date <= +now) {
            expire = "style='opacity: 0.5'";
            hide = "style='display: none'";
        }
        $('#eventlist').append("<li " + expire + ">" + "Title: " + item.Titel + " Place: " + item.Ort + " Till: " + item.Ablaufdatum + "<button " + hide + " id='detail' data-id=" + item.ID + " onClick='displaytermin(" + item.ID + ")' class='border-step2'>Details</button> <button id='delete' data-id='" + item.ID + "' class='border-step2' onClick='deletetermin(" + item.ID + ")' >Delete</button></li><div id=" + item.ID + "><div id='comments" + item.ID + "'></div></div><hr>");
    });
});
//---------------------------IF CLICKED ON DETAILS LOAD TERMINOPTIONEN,COMMENTS AND SEND PARAMS FOR FORM IF FORM IS SUBMITTED-----------------
function displaytermin($id) {
    var evt = function () {
        return this;
    };
    if ($(evt).attr('value') == 'show') {
        $(evt).attr('value', 'hide');
        $('#' + $id).slideDown();
    }
    else {
        $(evt).attr('value', 'show');
        $('#' + $id).slideUp();
    }
    $.getJSON(restServer, { 'method': 'gettermin', 'param': $id }, function (data) {
        var vote = document.createElement("form");
        if ($('#' + 0 + $id).length < 1) {
            vote.id = "form" + $id;
            var user = document.createElement("input");
            user.type = "text";
            user.name = "user";
            user.id = "" + $id;
            user.required = true;
            user.placeholder = "Username";
            user.className = "border-step2";
            user.addEventListener("keyup", showresults);
            var comment = document.createElement("input");
            comment.type = "text";
            comment.name = "comment";
            comment.placeholder = "Comment here...";
            comment.className = "border-step2";
            var save = document.createElement("input");
            save.type = "submit";
            save.value = "Save";
            save.className = "border-step2";
            var br_1 = document.createElement("br");
            var comlabel = document.createElement("label");
            comlabel.htmlFor = "comment";
            comlabel.textContent = "Comment:";
            var userlabel = document.createElement("label");
            userlabel.htmlFor = "user";
            userlabel.textContent = "Username:";
            vote.appendChild(comlabel);
            vote.appendChild(comment);
            vote.appendChild(br_1);
            vote.appendChild(userlabel);
            vote.appendChild(user);
            var count_1 = 0;
            $('#' + $id).append(vote);
            data.forEach(function (item) {
                $("#form" + $id).append("<br><li id=" + 0 + $id + "> Date: " + item.Datum + "<br><br>Total Votings: " + item.Votings + "<input type='checkbox' name='vote[" + item.ID + "]' id=" + count_1 + " ></div></li><br>");
                count_1++;
            });
            vote.appendChild(save);
        }
        ;
    });
    $('form#form' + $id).on("submit", function (event) {
        var data = $("form#form" + $id).serialize() + "&id=" + $id;
        console.log(data);
        $.ajax({
            url: restServer,
            method: "POST",
            dataType: 'json',
            data: data,
            success: function (data) {
                alert($('form#form' + $id).serialize());
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.statusText);
                alert(xhr.responseText);
            }
        });
        event.preventDefault();
    });
    $.getJSON(restServer, { 'method': 'getComments', 'param': $id }, //get comments for this appointment
    function (data) {
        if ($('#cmt' + $id).length < 1) {
            data.forEach(function (item) {
                $('#comments' + $id).append("<li id='cmt" + $id + "'><small>" + item.Username + "</small>: " + item.Comment + "</li>");
            });
        }
    });
}
function showresults() {
    if (this.value.length == 0) {
        var text = document.getElementById("usersvote");
        text.innerHTML = " ";
        return;
    }
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var text = document.getElementById("usersvote");
            text.innerHTML = JSON.parse(JSON.stringify(this.responseText));
        }
    };
    xmlhttp.open("GET", "" + restServer + "?method=getusersvotes&q=" + this.value, true);
    xmlhttp.send();
}
function deletetermin($id) {
    var data = { 'method': 'deleteAppointment', 'id': $id };
    $.ajax({
        url: restServer,
        method: "POST",
        dataType: 'json',
        data: data
    });
}
//--------------------CREATE FORM-----------------------
function createinput(property, datatype) {
    var label = document.createElement("label");
    label.textContent = property;
    label.htmlFor = property;
    form.appendChild(label);
    var input = document.createElement("input");
    input.id = property;
    input.name = property;
    input.placeholder = property + "...";
    if (datatype === String) {
        input.type = "text";
        input.required = true;
    }
    else if (datatype === Date) {
        input.type = "date";
    }
    input.className = "border-step2";
    form.appendChild(input);
    var br = document.createElement("br");
    form.appendChild(br);
}
function pop() {
    $("#newappointmentform").show();
}
function hide() {
    $("#newappointmentform").hide();
}
var form = document.createElement("form"); //create form
createinput("Place", String);
createinput("Date", Date);
createinput("Name", String);
createinput("Till", Date);
var button = document.createElement("input");
button.id = "submit";
button.type = "submit";
button.innerHTML = "Submit";
button.className = "border-step2";
var add = document.createElement("button");
add.type = "button";
add.id = "addBtn";
add.innerHTML = "add";
add.className = "border-step2";
var closebutton = document.createElement("button");
closebutton.innerHTML = "close";
closebutton.type = "button";
closebutton.className = "border-step2";
closebutton.addEventListener("click", hide);
var br = document.createElement("br");
form.appendChild(closebutton);
form.appendChild(br);
form.appendChild(add);
form.appendChild(br);
form.appendChild(button);
form.id = "newappointmentform";
form.method = "POST";
(_a = document.getElementById("createapp")) === null || _a === void 0 ? void 0 : _a.appendChild(form);
$("#newappointmentform").hide();
var popup = document.createElement("button");
popup.innerHTML = "new";
popup.className = "border-step2";
popup.addEventListener("click", pop);
(_b = document.getElementById("mainpart")) === null || _b === void 0 ? void 0 : _b.appendChild(popup);
//---------------------------NEW APPOINTMENT REQUEST------------------------------
var that = this;
$(function () {
    $('form#newappointmentform').on("submit", function (event) {
        var data = $("form#newappointmentform").serialize();
        $.ajax({
            url: restServer,
            method: "POST",
            dataType: 'json',
            data: data,
            success: function (data) {
                alert($('form#newappointmentform').serialize());
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.statusText);
                alert(xhr.responseText);
            }
        });
        event.preventDefault();
    });
    var counter = 1;
    $("#addBtn") //-----------ADD TERMINOPTIONEN-------------
        .click(function () {
        var option = document.createElement("input");
        option.type = "date";
        option.id = "option" + counter;
        option.name = "option[" + counter + "]";
        form.insertBefore(option, button);
        counter++;
    });
    //delete function with jquery
    $("delete").on("click", function () {
        var id = $(that).attr("data-id");
        var data = { 'method': 'deleteAppointment', 'id': id };
        $.ajax({
            url: restServer,
            method: "POST",
            dataType: 'json',
            data: data
        });
    });
});
$(document).on("click", "#delete", function () {
    var $li = $(this).closest("li");
    var $hr = $(this).closest("hr");
    $li.remove();
    $hr.remove();
    console.log($hr);
});
